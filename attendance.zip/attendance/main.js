
 var totalClasses=function(){
 var noInitialDays=document.getElementById("inhowManyDays").value;
 var noClassEachDay= document.getElementById("inhowManyClass").value;
 var noHolidays=document.getElementById("inHolidays").value;
 var noNotCountClasses=document.getElementById("inNoperiods").value;
  var el=document.getElementById("disTotalClasses");
  var toClass=(((noInitialDays*noClassEachDay)-(noHolidays*noClassEachDay))-(noNotCountClasses));
  el.innerHTML="Total Classes"+":"+toClass;
  return toClass;
 }
 var absentClasses=function(){
   var noBunkClasses=document.getElementById("inBunk").value;
   var toPresent=totalClasses()-noBunkClasses;
   var fl=document.getElementById("disAbsentClasses");
   fl.innerHTML="Attended Classes"+":"+toPresent;
   return toPresent;
 }
 var attendance=function(){
   var attend=(absentClasses()/totalClasses())*100;
   var gl=document.getElementById("disAttendance");
   gl.innerHTML="Attendance"+":"+attend;
   return attend;
 }
  var reqattendance=function(){
     var x=document.getElementById("x").value;
     var t=document.getElementById("t").value;
     var repre=Math.ceil((x*t)/100);
     var rebun=Math.ceil(t-repre);
     var bl=document.getElementById("disreqp");
     bl.innerHTML="Required Classes"+":"+repre;
     var dl=document.getElementById("disreqa");
     dl.innerHTML="Possible Bunks"+":"+rebun;
 }
